package com.assya.github_uploader;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GithubUploaderApplicationTests {

	@Test
	void contextLoads() {
	}

}
